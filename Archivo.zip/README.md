# frenon-gitflow


### Crear un repositorio Vacío

```
echo "# new_ejemplo" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/mortegac/new_ejemplo.git
git push -u origin master
```
### Subir cambios a un repositorio existente
```
git remote add origin https://github.com/mortegac/frenon-gitflow.git
git push -u origin master
```